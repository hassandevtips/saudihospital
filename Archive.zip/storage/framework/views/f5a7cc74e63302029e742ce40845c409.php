<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['menu']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['menu']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<ul class="navigation clearfix">
    <!--[if BLOCK]><![endif]--><?php if($menu && $menu->items): ?>
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $menu->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="<?php echo e(isset($item['children']) && count($item['children']) > 0 ? 'dropdown' : ''); ?>">
        <a href="<?php echo e($item['url'] ?? '#'); ?>" <?php if(isset($item['blank']) && $item['blank']): ?> target="_blank" <?php endif; ?>>
            <?php echo e($item['title']); ?>

        </a>

        <!--[if BLOCK]><![endif]--><?php if(isset($item['children']) && count($item['children']) > 0): ?>
        <?php
        $childrenCount = count($item['children']);
        $columnsNeeded = min(4, ceil($childrenCount / 3));
        $chunkedChildren = array_chunk($item['children'], ceil($childrenCount / $columnsNeeded));
        ?>
        <div class="megamenu">
            <div class="row clearfix">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $chunkedChildren; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-<?php echo e(12 / $columnsNeeded); ?> column">
                    <ul>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $childGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e($child['url'] ?? '#'); ?>" <?php if(isset($child['blank']) && $child['blank']): ?>
                                target="_blank" <?php endif; ?>>
                                <?php echo e($child['title']); ?>

                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    <?php else: ?>
    
    <li><a href="/">Home</a></li>
    <li class="dropdown"><a href="#">About Us</a>
        <div class="megamenu">
            <div class="row clearfix">
                <div class="col-lg-4 column">
                    <ul>
                        <li><a href="#">Our History</a></li>
                        <li><a href="#">Core Values</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 column">
                    <ul>
                        <li><a href="#">Group Overview</a></li>
                        <li><a href="#">Board Members</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 column">
                    <ul>
                        <li><a href="#">Vision Mission</a></li>
                        <li><a href="#">Our Doctors</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </li>
    <li><a href="#">Our Doctors</a></li>
    <li><a href="#">Media</a></li>
    <li><a href="#">Contact Us</a></li>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</ul><?php /**PATH /Users/hassan/Downloads/Saudi Hospital/resources/views/components/navigation-menu.blade.php ENDPATH**/ ?>