<div>
    <div id="search-popup" class="search-popup">
        <div class="popup-inner">
            <div class="upper-box clearfix">
                <figure class="logo-box pull-left"><a href="/"><img src="<?php echo e(asset($settings['logo'])); ?>"
                            alt="<?php echo e($settings['site_name']); ?>"></a>
                </figure>
                <div class="close-search pull-right"><span class="far fa-times"></span></div>
            </div>
            <div class="overlay-layer"></div>
            <div class="auto-container">
                <div class="search-form">
                    <form method="post" action="#">
                        <div class="form-group">
                            <fieldset>
                                <input type="search" class="form-control" name="search-input" value=""
                                    placeholder="Type your keyword and hit" required>
                                <button type="submit"><i class="far fa-search"></i></button>
                            </fieldset>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- main header -->
    <header class="main-header header-style-two">
        <!-- header-top -->

        <div class="header-top">
            <div class="auto-container">
                <div class="top-inner">
                    <div class="left-column">
                        <ul class="info clearfix">
                            <li><?php echo e($settings['tagline']); ?></li>


                        </ul>
                    </div>
                    <div class="right-column">
                        <div class="schedule">العربية</div>
                        <ul class="social-links clearfix">
                            <li><a href="<?php echo e($settings['facebook']); ?>"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="<?php echo e($settings['twitter']); ?>"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="<?php echo e($settings['linkedin']); ?>"><i class="fab fa-linkedin-in"></i></a></li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- header-lower -->
        <div class="header-lower" style="border-bottom: 1px solid #ffffff24;">
            <div class="auto-container">
                <div class="outer-box">
                    <div class="logo-box">
                        <figure class="logo"><a href="/"><img src="<?php echo e(asset($settings['logo'])); ?>"
                                    alt="<?php echo e($settings['site_name']); ?>"></a></figure>
                    </div>
                    <div class="menu-area clearfix">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler">
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                        </div>
                        <nav class="main-menu navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                <?php if (isset($component)) { $__componentOriginal8f4b0c7aa39bbb03a7f48d2d78460146 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8f4b0c7aa39bbb03a7f48d2d78460146 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navigation-menu','data' => ['menu' => $menu]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navigation-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['menu' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($menu)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8f4b0c7aa39bbb03a7f48d2d78460146)): ?>
<?php $attributes = $__attributesOriginal8f4b0c7aa39bbb03a7f48d2d78460146; ?>
<?php unset($__attributesOriginal8f4b0c7aa39bbb03a7f48d2d78460146); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8f4b0c7aa39bbb03a7f48d2d78460146)): ?>
<?php $component = $__componentOriginal8f4b0c7aa39bbb03a7f48d2d78460146; ?>
<?php unset($__componentOriginal8f4b0c7aa39bbb03a7f48d2d78460146); ?>
<?php endif; ?>
                            </div>
                        </nav>
                    </div>
                    <div class="nav-right">
                        <div class="search-box-outer search-toggler">
                            <i class="icon-5"></i>
                        </div>
                        <div class="btn-box">
                            <a href="#" class="theme-btn btn-one">Appointment</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--sticky Header-->
        <div class="sticky-header">
            <div class="auto-container">
                <div class="outer-box">
                    <div class="logo-box">
                        <figure class="logo"><a href="/"><img src="<?php echo e(asset($settings['logo'])); ?>"
                                    alt="<?php echo e($settings['site_name']); ?>"></a></figure>
                    </div>
                    <div class="menu-area clearfix">
                        <nav class="main-menu clearfix">
                            <!--Keep This Empty / Menu will come through Javascript-->
                        </nav>
                    </div>
                    <div class="nav-right">
                        <div class="search-box-outer search-toggler">
                            <i class="icon-5"></i>
                        </div>
                        <div class="btn-box">
                            <a href="#" class="theme-btn btn-one">Appointment</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- main-header end -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><i class="fas fa-times"></i></div>

        <nav class="menu-box">
            <div class="nav-logo"><a href="/"><img src="<?php echo e(asset($settings['logo'])); ?>"
                        alt="<?php echo e($settings['site_name']); ?>" title="<?php echo e($settings['site_name']); ?>"></a></div>
            <div class="menu-outer">
                <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
            </div>
            <div class="contact-info">
                <h4>Contact Info</h4>
                <ul>
                    <li><?php echo e($settings['address']); ?></li>
                    <li><a href="tel:<?php echo e($settings['phone']); ?>"><?php echo e($settings['phone']); ?></a></li>
                    <li><a href="mailto:<?php echo e($settings['email']); ?>"><?php echo e($settings['email']); ?></a></li>
                </ul>
            </div>
            <div class="social-links">
                <ul class="clearfix">
                    <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                    <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                    <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                    <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                    <li><a href="#"><span class="fab fa-youtube"></span></a></li>
                </ul>
            </div>
        </nav>
    </div><!-- End Mobile Menu -->
</div>
<?php /**PATH /Users/hassan/Downloads/Saudi Hospital/resources/views/livewire/includes/header.blade.php ENDPATH**/ ?>