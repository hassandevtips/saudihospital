<div>
    <!-- banner-section -->
    <section class="banner-style-two centred p_relative">
        <div class="banner-carousel owl-theme owl-carousel owl-dots-none">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="slide-item p_relative">
                <div class="image-layer p_absolute" style="background-image:url(<?php echo e($banner->image_url); ?>)">
                </div>
                <div class="pattern-layer">
                    <div class="pattern-2" style="background-image: url(assets/images/shape/shape-12.png);">
                    </div>
                </div>
                <div class="auto-container">
                    <div class="content-box">
                        <h2><?php echo e($banner->title); ?></h2>
                        <!--[if BLOCK]><![endif]--><?php if($banner->description): ?>
                        <p><?php echo e($banner->description); ?></p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($banner->button_text && $banner->button_link): ?>
                        <div class="btn-box">
                            <a href="<?php echo e($banner->button_link); ?>" class="theme-btn btn-one"><?php echo e($banner->button_text); ?></a>
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="slide-item p_relative">
                <div class="image-layer p_absolute" style="background-image:url(assets/images/banner/banner-1.jpg)">
                </div>
                <div class="pattern-layer">
                    <div class="pattern-2" style="background-image: url(assets/images/shape/shape-12.png);">
                    </div>
                </div>
                <div class="auto-container">
                    <div class="content-box">
                        <h2>Trusted Healthcare Services</h2>
                        <p>Over the years, thanks to the trust of our community and the commitment of our
                            staff.!</p>
                        <div class="btn-box">
                            <a href="#" class="theme-btn btn-one">Meet Our Doctors</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </section>
    <!-- banner-section end -->
</div><?php /**PATH /Users/hassan/Downloads/Saudi Hospital/resources/views/livewire/components/banner-slider.blade.php ENDPATH**/ ?>