<?php

use Illuminate\Support\Facades\Route;
use App\Livewire\HomePage;
use App\Livewire\DepartmentDoctors;
use App\Livewire\PageView;
use App\Models\Page;

Route::get('/', HomePage::class)->name('home');
Route::get('/doctors', DepartmentDoctors::class)->name('department-doctors');

// Dynamic page routes
Route::get('/{slug}', PageView::class)
    ->where('slug', '[a-z0-9-]+')
    ->name('page');
