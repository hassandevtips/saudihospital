<div>
    @include($templateView)
</div>
